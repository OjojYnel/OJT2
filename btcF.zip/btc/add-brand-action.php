
<center>
<?php
include 'config.php';
  session_start();

  if(isset($_POST['brand']))
  {
   
    $bname = $_POST['bname'];


    $query = "INSERT INTO `brands`(`brand_name`) VALUES ('$bname')";

    $result = mysqli_query($con,$query);

    if($result) {

      echo 'Brand Added';
    }else{
      echo 'Brand, Not Added ';
    }


    header("refresh:1;url=add.php");
    }
?>
</center>