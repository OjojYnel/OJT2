<?php 

// Connect DB
     include 'config.php';

// Get ID from DB

if (isset($_GET['del_id'])) {
  
  $sql = "DELETE FROM products where product_id =" .$_GET['del_id'];

// Execute query

  if (mysqli_query($con, $sql)) {
  	header("refresh:1; url=products.php");

  	} else {
  		echo "Not Deleted";
  	}
  
}

