<?php
include 'config.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags-->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="au theme template">
  <meta name="author" content="Hau Nguyen">
  <meta name="keywords" content="au theme template">

  <!-- Title Page-->
  <title>Dashboard</title>

  <!-- Fontfaces CSS-->
  <link href="css/font-face.css" rel="stylesheet" media="all">
  <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
  <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
  <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

  <!-- Bootstrap CSS-->
  <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

  <!-- Vendor CSS-->
  <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
  <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
  <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
  <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
  <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
  <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
  <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

  <!-- Main CSS-->
  <link href="css/theme.css" rel="stylesheet" media="all">
  <script type="text/javascript" src="./js/purchase.js"></script>

</head>

<body class="animsition">
  <div class="page-wrapper">
    <!-- MENU SIDEBAR-->
    <aside class="menu-sidebar d-none d-lg-block">
      <div class="logo">
        <a href="index.php">
          <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
      </div>
      <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
          <ul class="list-unstyled navbar__list">
            <li><a class="js-arrow" href="#"><i class="fas fa-chart-bar"></i>Supplies</a>
              <ul class="list-unstyled navbar__sub-list js-sub-list">
               <li><a href="products.php">Products</a></li>
               <li><a href="Add.php">Add</a></li>
             </ul>
           </li>                       
           <li class="active has-sub"><a href="purchase.php"><i class="fas fa-table"></i>Purchase</a></li>
           <li><a href="issuance.php"><i class="far fa-check-square"></i>Issuance</a></li>                   
           <li><a class="js-arrow" href="#"><i class="fas fa-copy"></i>Generate Report</a> 
              <ul class="list-unstyled navbar__sub-list js-sub-list">
                                 <li>
                                    <a href="report_purchase.php">Purchases</a>
                                </li>
                                <li>
                                    <a href="report_issue.php">Issuance</a>
                                </li>
      
           </li>
         </ul>
       </nav>
     </div>
   </aside>
   <!-- END MENU SIDEBAR-->

   <!-- PAGE CONTAINER-->
   <div class="page-container">
    <!-- HEADER DESKTOP-->
    <header class="header-desktop">
      <div class="section__content section__content--p30">

      </div>
    </header>
    <!-- HEADER DESKTOP-->

    <!-- MAIN CONTENT-->
    <div class="main-content">
      <div class="section__content section__content--p100">  
        <div class="container">
          <div class="row">
            <div class="col-md-12 mx-auto">
              <div class="card" style="box-shadow: 0 0 25px 0 lightgrey;">
                <div class="card-header"><h4 align="center">New Purchases</h4></div>
                <div class="card-body">
                  <form action="insert.php" method="post">
                    <div class="form-group row">
                      <label>P.O. Date</label>
                      <div class="col-sm-2">
                        <input type="text" name="added_date" class="form-control form-control-sm" value="<?php echo date ("Y-m-d");?>" required>
                      </div>
                      <div class="form-group row">
                        <label>P.O. Number</label>
                        <div class="col-sm-5">
                          <input type="text" name="pnum" class="form-control form-control-sm"  placeholder="Enter P.O.#" required>
                        </div>
                      </div>
                    </div>
                    <div class="card" style="box-shadow: 0 0 15px 0 lightgrey;">
                      <div class="card-body">
                        <h3>Make Purchase List</h3>
                        <table align="center">
                          <thead>
                            <tr>
                              <th></th>
                              <th style="text-align:center;">Product Name</th>
                              <th style="text-align:center;">Code</th>
                              <th style="text-align:center;">Brand</th>
                              <th style="text-align:center;">Unit</th>
                              <th style="text-align:center;">Category</th>
                              <th style="text-align:center;">Source</th>
                              <th style="text-align:center;">Quantity</th>
                              <th style="text-align:center;">Price</th>
                              <th style="text-align:center;">Amount</th>
                            </tr>
                          </thead>

                          <tbody>
                            <tr>
                              <td><b id="number"></td>

                               <?php 
                               $sql = "SELECT * from products";
                               $result1 = mysqli_query($con, $sql)
                               ?>

                               <td>
                                <select name="pname"   type="text" class="form-control-sm form-control" required>
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['product_name']; ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </td>     

                              <?php 
                              $sql = "SELECT * from products";
                              $result1 = mysqli_query($con, $sql)
                              ?>
                              
                              <td>
                                <select name="pcode"   type="text" class="form-control-sm form-control">
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['product_code']; ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </td>


                              <?php 
                              $sql = "SELECT * from brands";
                              $result1 = mysqli_query($con, $sql)
                              ?>

                              <td>
                                <select name="pbrand" type="text" class="form-control-sm form-control" required>
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['brand_name']; ?></option>
                                  <?php endwhile; ?>  
                                </select>
                              </td>

                              <?php 
                              $sql = "SELECT * from units";
                              $result1 = mysqli_query($con, $sql)
                              ?>

                              <td>
                                <select name="punit" type="text" class="form-control-sm form-control" required>
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['unit_of_issue']; ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </td>

                              <?php 
                              $sql = "SELECT * from categories";
                              $result1 = mysqli_query($con, $sql)
                              ?>

                              <td>
                                <select name="pcategory" type="text" class="form-control-sm form-control" required>
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['category_name']; ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </td>

                              <?php 
                              $sql = "SELECT * from funds";
                              $result1 = mysqli_query($con, $sql)
                              ?>

                              <td>
                                <select name="fund" type="text" class="form-control-sm form-control" required>
                                  <option value="0"> Choose </option>
                                  <?php while ($row1 = mysqli_fetch_array($result1)):; ?>
                                    <option> <?php echo $row1['fund_source']; ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </td>

                              <td>
                                <input type="number" name="quantity" class="form-control form-control-sm">
                              </td>
                              <td>
                                <input type="number" name="price" class="form-control form-control-sm">
                              </td>
                               <td>
                                <input type="number" name="amt" class="form-control form-control-sm">
                              </td>

                            </tr>
                          </tbody>

                        </table> <!-- Table Ends -->
                        <center style="padding:10px;">
                          <button type="submit" id="add" style="width:200px;" class="btn btn-success"> <i class="zmdi zmdi-plus"></i>Add Order Purchased</button>
                        </center>
                      </div> <!-- Card Ends -->
                    </div> <!-- Order List Card Ends -->
                    <P></P>     
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="copyright">
            <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->
  </div>
</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>
</html>
<!-- end document-->
