<?php 

// Connect DB
     include 'config.php';

// Get ID from DB

if (isset($_GET['del_id'])) {
  
  $sql = "DELETE FROM categories where category_id =" .$_GET['del_id'];

// Execute query

  if (mysqli_query($con, $sql)) {
  	header("refresh:1; url=products.php");

  	} else {
  		echo "Not Deleted";
  	}
  
}

