<center>
<?php
include 'config.php';


$rsnum = $_POST['rsnum'];
$rsdate = $_POST['added_date'];
$rscode = $_POST['rscode'];
$product_name = $_POST['pname'];
$product_category = $_POST['pcategory'];
$product_brand = $_POST['pbrand'];
$punit = $_POST['punit'];
$fund = $_POST['fund'];
$qty = $_POST['quantity'];
$price = $_POST['price'];



$sql = "INSERT INTO issue (rsmi_num,rsmi_date,product_code,product_name,category_name,brand_name,unit_of_issue,fund_source,quantity,price) VALUES ('$rsnum','$rsdate','$rscode','$product_name','$product_category','$product_brand','$punit','$fund','$qty','$price')";

if(!mysqli_query($con,$sql)){
	echo 'Not Inserted';
}else{
	echo 'Inserted';
}
	
header("refresh:2;url=issuance.php");

?>
</center>