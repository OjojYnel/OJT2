  <center>
<?php
include 'config.php';
  session_start();

  if(isset($_POST['unit']))
  {
   
    $uname = $_POST['uname'];


    $query = "INSERT INTO `units`(`unit_of_issue`) VALUES ('$uname')";

    $result = mysqli_query($con,$query);

    if($result) {

    echo 'Unit Added';
    }else{
      echo 'Unit, Not Added ';
    }


    header("refresh:1;url=add.php");


    }
?>
</center>