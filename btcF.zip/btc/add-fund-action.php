<center>
<?php
include 'config.php';
  session_start();

  if(isset($_POST['fund']))
  {
   
    $fsource = $_POST['fsource'];


    $query = "INSERT INTO `funds`(`fund_source`) VALUES ('$fsource')";

    $result = mysqli_query($con,$query);

    if($result) {
      echo 'Fund Source Added';
    }else{
      echo 'Fund Source, Not Added ';
    }
    header("refresh:1;url=add.php");

    }
?>
</center>