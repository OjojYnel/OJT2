<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">
    <!-- Title Page-->
    <title>SUPPLIES LIST</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
</head>
<body class="animsition">
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="index.php">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a class="js-arrow" href="#">
                                <i class="fas fa-chart-bar"></i>Supplies</a>
                                <ul class="list-unstyled navbar__sub-list js-sub-list">
                                 <li class="active has-sub">
                                    <a href="products.php">Products</a>
                                </li>
                                <li>
                                    <a href="Add.php">Add</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="purchase.php">
                                <i class="fas fa-table"></i>Purchase</a>
                            </li>
                            <li>
                                <a href="issuance.php">
                                    <i class="far fa-check-square"></i>Issuance</a>
                                </li>                          
                            </ul>       
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->
        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30" align="center">
                    <iframe src="http://free.timeanddate.com/clock/i6cof2h4/n145/fn8/fs20/ftb/pa10/tt0/tm1/td1/th2/tb1" frameborder="0" width="453" height="43"></iframe>
                </div>
            </header>
            <!-- HEADER DESKTOP-->
            <!-- MAIN CONTENT-->
            <div class="main-content">
             <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="card">
                            <div class="card-header">
                                <h2 align="center">Supplies</h2>
                            </div>
                            <div class="card-body">
                                <div class="custom-tab">
                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="custom-nav-products-tab" data-toggle="tab" href="#custom-nav-products" role="tab" aria-controls="custom-nav-products"
                                            aria-selected="true">Products</a>
                                            <a class="nav-item nav-link" id="custom-nav-categories-tab" data-toggle="tab" href="#custom-nav-categories" role="tab" aria-controls="custom-nav-categories"
                                            aria-selected="false">Categories</a>
                                            <a class="nav-item nav-link" id="custom-nav-brands-tab" data-toggle="tab" href="#custom-nav-brands" role="tab" aria-controls="custom-nav-brands"
                                            aria-selected="false">Brands</a>
                                            <a class="nav-item nav-link" id="custom-nav-units-tab" data-toggle="tab" href="#custom-nav-units" role="tab" aria-controls="custom-nav-units"
                                            aria-selected="false">Units</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="custom-nav-products" role="tabpanel" aria-labelledby="custom-nav-products-tab">
                                            <div class="col-md-12">
                                                <div class="overview-wrap">
                                                    <div class="table-responsive table-responsive-data2">
                                                        <table class="table table-data2" id="editable_table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Product ID</th>
                                                                    <th>Product Code</th>
                                                                    <th>Product Name</th>
                                                                    <th>Added Date</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $perpage = 15;
                                                                if(isset($_GET["page"])){
                                                                    $page = intval($_GET["page"]);
                                                                }else {
                                                                    $page = 1;
                                                                }
                                                                $calc = $perpage * $page;
                                                                $start = $calc - $perpage;
                                                                $sql = "SELECT * FROM products LIMIT $start, $perpage";
                                                                $result = mysqli_query($con,$sql);
                                                                $rows = mysqli_num_rows($result);
                                                                if($rows){
                                                                    $i = 0;
                                                                    while($row = mysqli_fetch_array($result)){
                                                                        echo '
                                                                        <tr>
                                                                        <td>'.$row["product_id"].'</td>
                                                                        <td>'.$row["product_code"].'</td>
                                                                        <td>'.$row["product_name"].'</td>
                                                                        <td>'.$row["added_date"].'</td>
                                                                        <td>'.'<a href=\'edit-products.php?edit_id=' .$row['product_id'].'\'>Edit</a>'.'</td>
                                                                        <td>'.'<a href=\'delete-products.php?del_id=' .$row['product_id'].'\'><span class="status--denied">Delete</span></a>'.'</td>
                                                                        </tr>
                                                                        ';
                                                                    }
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                        <?php
                                                        if(isset($page)){
                                                            $result = mysqli_query($con,"select Count(*) as Total from products");
                                                            $rows = mysqli_num_rows($result);
                                                            if($rows){
                                                                $rs = mysqli_fetch_assoc($result);
                                                                $total = $rs["Total"];
                                                            }
                                                            $totalPages = ceil($total / $perpage);
                                                            if($page <=1 ){
                                                                echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";
                                                            }else{
                                                                $j = $page - 1;
                                                                echo "<span><a id='page_a_link' href='products.php?page=$j'>< Prev</a></span>";
                                                            }
                                                            for($i=1; $i <= $totalPages; $i++){
                                                                if($i<>$page){
                                                                    echo "<span><a id='page_a_link' href='products.php?page=$i'>$i</a></span>";
                                                                }else{
                                                                    echo "<span id='page_links' style='font-weight: bold;'>$i</span>";
                                                                }
                                                            }
                                                            if($page == $totalPages ){
                                                                echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";
                                                            }else{
                                                                $j = $page + 1;
                                                                echo "<span><a id='page_a_link' href='products.php?page=$j'>Next</a></span>";
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-categories" role="tabpanel" aria-labelledby="custom-nav-categories-tab">
                                            <div class="col-md-12">
                                                <div class="overview-wrap">
                                                    <div class="table-responsive table-responsive-data2">
                                                        <table class="table table-data2" id="editable_table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Category ID</th>
                                                                    <th>Category Name</th>
                                                                    <th>Added Date</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $perpage = 15;
                                                                if(isset($_GET["page"])){
                                                                    $page = intval($_GET["page"]);
                                                                }else {
                                                                    $page = 1;
                                                                }
                                                                $calc = $perpage * $page;
                                                                $start = $calc - $perpage;
                                                                $sql = "SELECT * FROM categories LIMIT $start, $perpage";
                                                                $result = mysqli_query($con,$sql);
                                                                $rows = mysqli_num_rows($result);
                                                                if($rows){
                                                                    $i = 0;
                                                                    while($row = mysqli_fetch_array($result)){
                                                                        echo '
                                                                        <tr>
                                                                        <td>'.$row["category_id"].'</td>
                                                                        <td>'.$row["category_name"].'</td>
                                                                        <td>'.$row["added_date"].'</td>
                                                                        <td>'.'<a href=\'edit-category.php?edit_id=' .$row['category_id'].'\'>Edit</a>'.'</td>
                                                                        <td>'.'<a href=\'delete-category.php?del_id=' .$row['category_id'].'\'><span class="status--denied">Delete</span></a>'.' </td>
                                                                        </tr>
                                                                        ';
                                                                    }
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                        <?php
                                                        if(isset($page)){
                                                            $result = mysqli_query($con,"select Count(*) as Total from categories");
                                                            $rows = mysqli_num_rows($result);
                                                            if($rows){
                                                                $rs = mysqli_fetch_assoc($result);
                                                                $total = $rs["Total"];
                                                            }
                                                            $totalPages = ceil($total / $perpage);
                                                            if($page <=1 ){
                                                                echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";
                                                            }else{
                                                                $j = $page - 1;
                                                                echo "<span><a id='page_a_link' href='products.php?page=$j'>< Prev</a></span>";
                                                            }
                                                            for($i=1; $i <= $totalPages; $i++){
                                                                if($i<>$page){
                                                                    echo "<span><a id='page_a_link' href='products.php?page=$i'>$i</a></span>";
                                                                }else{
                                                                    echo "<span id='page_links' style='font-weight: bold;'>$i</span>";
                                                                }
                                                            }
                                                            if($page == $totalPages ){
                                                                echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";
                                                            }else{
                                                                $j = $page + 1;
                                                                echo "<span><a id='page_a_link' href='products.php?page=$j'>Next</a></span>";
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-brands" role="tabpanel" aria-labelledby="custom-nav-brands-tab">
                                         <div class="col-md-12">
                                            <div class="overview-wrap">
                                                <div class="table-responsive table-responsive-data2">
                                                    <table class="table table-data2" id="editable_table">
                                                        <thead>
                                                            <tr>
                                                                <th>Brand ID</th>
                                                                <th>Brand Name</th>
                                                                <th>Added Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $perpage = 15;
                                                            if(isset($_GET["page"])){
                                                                $page = intval($_GET["page"]);
                                                            }else {
                                                                $page = 1;
                                                            }
                                                            $calc = $perpage * $page;
                                                            $start = $calc - $perpage;
                                                            $sql = "SELECT * FROM brands LIMIT $start, $perpage";
                                                            $result = mysqli_query($con,$sql);
                                                            $rows = mysqli_num_rows($result);
                                                            if($rows){
                                                                $i = 0;
                                                                while($row = mysqli_fetch_array($result)){
                                                                    echo '
                                                                    <tr>
                                                                    <td>'.$row["brand_id"].'</td>
                                                                    <td>'.$row["brand_name"].'</td>
                                                                    <td>'.$row["added_date"].'</td>
                                                                    <td>'.'<a href=\'edit-brand.php?edit_id=' .$row['brand_id'].'\'>Edit</a>'.'</td>
                                                                    <td>'.'<a href=\'delete-brand.php?del_id=' .$row['brand_id'].'\'><span class="status--denied">Delete</span></a>'.' </td>
                                                                    </tr>
                                                                    ';
                                                                }
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                    <?php
                                                    if(isset($page)){
                                                        $result = mysqli_query($con,"select Count(*) as Total from brands");
                                                        $rows = mysqli_num_rows($result);

                                                        if($rows){
                                                            $rs = mysqli_fetch_assoc($result);
                                                            $total = $rs["Total"];
                                                        }
                                                        $totalPages = ceil($total / $perpage);
                                                        if($page <=1 ){
                                                            echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";
                                                        }else{
                                                            $j = $page - 1;
                                                            echo "<span><a id='page_a_link' href='products.php?page=$j'>< Prev</a></span>";
                                                        }
                                                        for($i=1; $i <= $totalPages; $i++){
                                                            if($i<>$page){
                                                                echo "<span><a id='page_a_link' href='products.php?page=$i'>$i</a></span>";
                                                            }else{
                                                                echo "<span id='page_links' style='font-weight: bold;'>$i</span>";
                                                            }
                                                        }
                                                        if($page == $totalPages ){
                                                            echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";
                                                        }else{
                                                            $j = $page + 1;
                                                            echo "<span><a id='page_a_link' href='products.php?page=$j'>Next</a></span>";
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="custom-nav-units" role="tabpanel" aria-labelledby="custom-nav-units-tab">
                                        <div class="col-md-12">
                                            <div class="overview-wrap">
                                                <div class="table-responsive table-responsive-data2">
                                                    <table class="table table-data2" id="editable_table">
                                                        <thead>
                                                            <tr>
                                                                <th>Unit ID</th>
                                                                <th>Unit of Issue</th>
                                                                <th>Added Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $perpage = 15;
                                                            if(isset($_GET["page"])){
                                                                $page = intval($_GET["page"]);
                                                            }else {
                                                                $page = 1;
                                                            }
                                                            $calc = $perpage * $page;
                                                            $start = $calc - $perpage;
                                                            $sql = "SELECT * FROM units LIMIT $start, $perpage";
                                                            $result = mysqli_query($con,$sql);
                                                            $rows = mysqli_num_rows($result);
                                                            if($rows){
                                                                $i = 0;
                                                                while($row = mysqli_fetch_array($result)){
                                                                    echo '
                                                                    <tr>
                                                                    <td>'.$row["unit_id"].'</td>
                                                                    <td>'.$row["unit_of_issue"].'</td>
                                                                    <td>'.$row["added_date"].'</td>
                                                                    <td>'.'<a href=\'edit-unit.php?edit_id=' .$row['unit_id'].'\'>Edit</a>'.'</td>
                                                                    <td>'.'<a href=\'delete-unit.php?del_id=' .$row['unit_id'].'\'><span class="status--denied">Delete</span></a>'.' </td>
                                                                    </tr>
                                                                    ';
                                                                }
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                    <?php
                                                    if(isset($page)){
                                                        $result = mysqli_query($con,"select Count(*) as Total from units");
                                                        $rows = mysqli_num_rows($result);

                                                        if($rows){
                                                            $rs = mysqli_fetch_assoc($result);
                                                            $total = $rs["Total"];
                                                        }
                                                        $totalPages = ceil($total / $perpage);
                                                        if($page <=1 ){
                                                            echo "<span id='page_links' style='font-weight: bold;'>Prev</span>";
                                                        }else{
                                                            $j = $page - 1;
                                                            echo "<span><a id='page_a_link' href='products.php?page=$j'>< Prev</a></span>";
                                                        }
                                                        for($i=1; $i <= $totalPages; $i++){
                                                            if($i<>$page){
                                                                echo "<span><a id='page_a_link' href='products.php?page=$i'>$i</a></span>";
                                                            }else{
                                                                echo "<span id='page_links' style='font-weight: bold;'>$i</span>";
                                                            }
                                                        }
                                                        if($page == $totalPages ){
                                                            echo "<span id='page_links' style='font-weight: bold;'>Next ></span>";
                                                        }else{
                                                            $j = $page + 1;
                                                            echo "<span><a id='page_a_link' href='products.php?page=$j'>Next</a></span>";
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                            <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
</div>
</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
