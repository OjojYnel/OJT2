<center>
<?php
include 'config.php';
  session_start();

  if(isset($_POST['name']))
  {
   
    $pname = $_POST['pname'];
    $icname = $_POST['icname'];


    $query = "INSERT INTO `products`(`product_code`, `product_name`) VALUES ('$icname','$pname')";
    $result = mysqli_query($con,$query);

    if($result) {
echo 'Product Added';
    }else{
      echo 'Product, Not Added ';
    }


    header("refresh:1;url=add.php");

    }
?>
</center>