-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2018 at 07:44 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `btcadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `added_date`) VALUES
(1, 'Safeguard', '2018-08-01 12:57:10'),
(2, 'Liquid Sosa', '2018-08-01 15:32:21'),
(3, 'Surf', '2018-08-01 15:32:28'),
(4, 'Dazz', '2018-08-01 15:32:35'),
(5, 'Dove', '2018-08-01 15:38:07');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `added_date`) VALUES
(1, 'Office Supplies', '2018-08-01 11:18:31'),
(2, 'Construction Materials', '2018-08-01 11:18:31'),
(3, 'Other Supplies and Materials', '2018-08-01 11:18:57'),
(4, 'Agricultural Supplies', '2018-08-01 11:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `funds`
--

CREATE TABLE `funds` (
  `fund_id` int(11) NOT NULL,
  `fund_source` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `funds`
--

INSERT INTO `funds` (`fund_id`, `fund_source`, `added_date`) VALUES
(1, 'General Fund', '2018-09-04 13:36:59'),
(2, 'Revolving Fund', '2018-09-04 13:37:09');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `issue_id` int(11) NOT NULL,
  `rsmi_num` varchar(255) NOT NULL,
  `rsmi_date` date NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `unit_of_issue` varchar(255) NOT NULL,
  `fund_source` enum('General Fund','Revolving Fund') NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `issue_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `added_date`) VALUES
(1, '990-001A', 'Bathroom Soap - 25g', '2018-08-01 09:08:39'),
(2, '990-001B', 'Bathroom Soap - 90g', '2018-08-01 09:08:32'),
(3, '990-002A', 'Broom - Soft', '2018-08-01 09:09:46'),
(4, '990-002B', 'Broom - Stick', '2018-08-01 09:13:50'),
(5, '990-003', 'Cleanser - Scouring Powder, 350g', '2018-08-01 09:13:50'),
(6, '990-004A', 'Clog Remover', '2018-08-01 09:13:50'),
(7, '990-004B', 'Clog Remover', '2018-08-01 09:13:50'),
(8, '990-005', 'Cockroach Killer', '2018-08-01 09:13:50'),
(9, '990-006', 'Detergent Bar', '2018-08-01 09:13:50'),
(10, '990-007A', 'Detergent Powder - 1kg./pack, All purpose', '2018-08-01 09:13:50'),
(11, '990-007B', 'Detergent Powder - 500g./pack, All purpose', '2018-08-01 09:13:50'),
(12, '990-008', 'Dipper - Plastic', '2018-08-01 09:13:50'),
(13, '990-009A', 'Dishwashing Paste', '2018-08-01 09:13:50'),
(14, '990-009B', 'Dishwashing Paste - Refill, 200g/pouch', '2018-08-01 09:53:51'),
(15, '990-009C', 'Dishwashing Powder ', '2018-08-01 09:53:51'),
(16, '990-010A', 'Disinfectant Spray - 340g', '2018-08-01 09:53:51'),
(17, '990-010B', 'Disinfectant Spray - 400g', '2018-08-01 09:53:51'),
(18, '990-010C', 'Disinfectant Spray', '2018-08-01 09:53:51'),
(19, '990-010D', 'Disinfectant Spray', '2018-08-01 09:53:51'),
(20, '990-011', 'Doormat - Foot Rug, Cloth, 12x20in', '2018-08-01 09:53:51'),
(21, '990-011B', 'Doormat - Cotton Rag, 7in diameter, assorted colors', '2018-08-01 09:53:51'),
(22, '990-011C', 'Cloth Rag - all Cotton 32 pcs/bundle', '2018-08-01 09:53:51'),
(23, '990-012', 'Dust Pan - Plastic with Handle', '2018-08-01 09:53:51'),
(24, '990-019', 'Fabric Conditioner/Softener - 35ml', '2018-08-01 09:53:51'),
(25, '990-014A', 'Floor Polisher Brush/Bracket - for Victor 13in', '2018-08-01 09:53:51'),
(26, '990-014B', 'Floor Polisher Brush/Bracket - for Victor 16in', '2018-08-01 09:53:51'),
(27, '990-015A', 'Floor Wax - Liquid Type, 3.75-5.0L, Plastic Container', '2018-08-01 09:53:51'),
(28, '990-015B', 'Floor Wax - Paste, Natural, 2.0 Kg', '2018-08-01 09:53:51'),
(29, '990-015C', 'Floor Wax - Paste, Red, 2.0 Kg', '2018-08-01 09:53:51'),
(30, '990-016', 'Furniture Cleaner - Min. 300 ml/can', '2018-08-01 09:53:51'),
(31, '990-017', 'Gloves - Rubber', '2018-08-01 09:53:51'),
(32, '990-018', 'Hand Brush - without handle, peanut brush', '2018-08-01 09:53:51'),
(33, '990-019A', 'Insecticide - Sprayer', '2018-08-01 09:53:51'),
(34, '990-019B', 'Insecticide', '2018-08-01 09:53:51'),
(35, '990-019C', 'Insecticide - Baygon, 600 ml (42g can)', '2018-08-01 09:53:51'),
(36, '990-020', 'Magic Mop Cleaner', '2018-08-01 09:53:51'),
(37, '990-021', 'Mop Handle - Screw Type, wooden/metal handle', '2018-08-01 09:53:51'),
(38, '990-022', 'Mop Head - 100% Rayon, 400g', '2018-08-01 09:53:51'),
(39, '990-023A', 'Pail - Plastic, 10 Lit. Capacity', '2018-08-01 09:53:51'),
(40, '990-023B', 'Pail - Plastic, 15 Lit', '2018-08-01 09:53:51'),
(41, '990-023C', 'Pail - Plastic, 16 Lit. Capacity', '2018-08-01 09:53:51'),
(42, '990-024', 'Plant Pot - Medium', '2018-08-01 09:53:51'),
(43, '990-025', 'Push Brush - Wooden Handle', '2018-08-01 09:53:51'),
(44, '990-026A', 'Rubber Mat ', '2018-08-01 09:53:51'),
(45, '990-026B', 'Rubber', '2018-08-01 09:53:51'),
(46, '990-027A', 'Scouring Pad/Scotch Brite - Economy Size', '2018-08-01 09:53:51'),
(47, '990-027B', 'Scouring Pad/Scotch Brite - with foam', '2018-08-01 09:53:51'),
(48, '990-028', 'Steel Wool', '2018-08-01 09:53:51'),
(49, '990-029A', 'Toilet Bowl & Urinal Cleaner', '2018-08-01 09:53:51'),
(50, '990-029B', 'Toilet Bowl Brush', '2018-08-01 09:53:51'),
(51, '990-030', 'Toilet Deodorant Cake', '2018-08-01 09:53:51'),
(52, '990-031', 'Toilet Pump - Plunger, Rubberized, Wooden Handle', '2018-08-01 09:53:51'),
(53, '990-032', 'Toilet Tissue', '2018-08-01 09:53:51'),
(54, '990-033', 'Trashbag - Plastic, Black, XXL', '2018-08-01 09:53:51'),
(55, '990-034', 'Trashliner - Plastic, Black, Small', '2018-08-01 09:53:51'),
(56, '990-035', 'Twine - Plastic, 1 kilo per roll', '2018-08-01 09:53:51'),
(57, '990-036', 'Waste Basket - Plastic', '2018-08-01 09:53:51'),
(58, '990-037', 'Window Glass Cleaner', '2018-08-01 09:53:51'),
(59, '990-038', 'Bleach', '2018-08-01 09:53:51'),
(60, '990-039', 'Pillow Case - 18in, Whote, Cotton, w/Personalized BTC Embroidery', '2018-08-01 09:53:51'),
(61, '990-040', 'Pillows - Standard, Fiber-fill, Washable, White, 18x23 (700 grams)', '2018-08-01 09:53:51'),
(62, '990-041', 'Air Freshner', '2018-08-01 09:53:51'),
(63, '990C-001', 'Airpot - 4 lits. With dispenser', '2018-08-01 09:53:51'),
(64, '990C-002', 'Casserole, stainless (3 sizes)', '2018-08-01 10:47:09'),
(65, '990C-003', 'Chopping Board - Plastic', '2018-08-01 10:47:09'),
(66, '990C-004', 'Cups & Saucers', '2018-08-01 10:47:09'),
(67, '990C-005A', 'Face Mirror - 16x14', '2018-08-01 10:47:09'),
(68, '990C-005B', 'Mirror - Frameless, Rectangular, 14 x 18 (w/trimming)', '2018-08-01 10:47:09'),
(69, '990C-006A', 'Kitchen Knife - 6in, HD', '2018-08-01 10:47:09'),
(70, '990C-006B', 'Kitchen Knife - 8in', '2018-08-01 10:47:09'),
(71, '990C-006C', 'Kitchen Knife - 8in, HD', '2018-08-01 10:47:09'),
(72, '990C-007', 'LPG Hose - 1-1/2 Length', '2018-08-01 10:47:09'),
(73, '990C-008', 'Paper Cup - Vinyl/Plastic Coat, 48 mm', '2018-08-01 10:47:09'),
(74, '990C-008', 'Plate Rack - with Cover', '2018-08-01 10:47:09'),
(75, '990C-009', 'Rice Pot', '2018-08-01 10:47:09'),
(76, '990C-010', 'Rice Spoon', '2018-08-01 10:47:09'),
(77, '990C-011', 'Soup Laddle - Stainless', '2018-08-01 10:47:09'),
(78, '990C-012', 'Spoon/Fork Draine - Plastic', '2018-08-01 10:47:09'),
(79, '990C-013', 'Turner - Stainless', '2018-08-01 10:47:09'),
(80, '990C-014', 'Vegetable Laddle', '2018-08-01 10:47:09'),
(81, '990IT-001', 'External Hard Drive 1 TB 2.5 HDD 3', '2018-08-01 10:47:09'),
(82, '990IT-002A', 'Flash Drive - 16 GB USB 2.0 plug & play', '2018-08-01 10:47:09'),
(83, '990IT-002B', 'Flash Drive - 8 GB USB 2.0 plug & play', '2018-08-01 10:47:09'),
(84, '990IT-003', 'Switch Hub - 24 ports', '2018-08-01 10:47:09'),
(85, '990IT-004', 'DVD Reqritable - 4x speed, 4.7 gb capacity', '2018-08-01 10:47:09'),
(86, '990IT-005', 'RJ 45', '2018-08-01 10:47:09'),
(87, '990IT-006', 'Internet Cable', '2018-08-01 10:47:09'),
(88, '990IT-007', 'Mouse - Optical, USB connection type', '2018-08-01 10:47:09'),
(89, '010-001A', 'Air Freshner - 280 ml', '2018-08-01 10:47:09'),
(90, '010-001B', 'Air Freshner - Plastic Sprayer', '2018-08-01 10:47:09'),
(91, '010-002A', 'Alcohol - 70%, 500 ml', '2018-08-01 10:47:09'),
(92, '010-002B', 'Alcohol', '2018-08-01 10:47:09'),
(93, '010-003A', 'Ballpen - Black', '2018-08-01 10:47:09'),
(94, '010-003B', 'Ballpen - Black', '2018-08-01 10:47:09'),
(95, '010-003C', 'Ballpen - Black', '2018-08-01 10:47:09'),
(96, '010-003D', 'Ballpen - Black', '2018-08-01 10:47:09'),
(97, '010-003E', 'Ballpen - Red', '2018-08-01 10:47:09'),
(98, '010-003F', 'Ballpen - Blue', '2018-08-01 10:47:09'),
(99, '010-004A', 'Battery, Alkaline,  2pcs/pack', '2018-08-01 10:47:09'),
(100, '010-004B', 'Battery, Alkaline, 2 pcs/pack', '2018-08-01 10:47:09'),
(101, '010-004C', 'Battery - 4 pcs/pack', '2018-08-01 10:47:09'),
(102, '010-005A', 'Blade, for Heavy Duty Cutter, (L500)', '2018-08-01 10:47:09'),
(103, '010-005B', 'Blade, small', '2018-08-01 10:47:09'),
(104, '010-006A', 'Bond paper - A4', '2018-08-01 10:47:09'),
(105, '010-006B', 'Bond Paper - A4, 80 gms. Subs. 24', '2018-08-01 10:47:09'),
(106, '010-006C', 'Bond Paper - Legal, 80 gsm. Subs. 24', '2018-08-01 10:47:09'),
(107, '010-006D', 'Bond Paper - A4, Premium Grade, 70 Gsm. Subs. 20', '2018-08-01 10:47:09'),
(108, '010-006E', 'Bond Paper - Legal, 70 Gsm. Subs. 20', '2018-08-01 10:47:09'),
(109, '010-006F', 'Bond Paper - Legal', '2018-08-01 10:47:09'),
(110, '010-006G', 'Bond Paper - 70 Gsm', '2018-08-01 10:47:09'),
(111, '010-006H', 'Bond Paper - Short', '2018-08-01 10:47:09'),
(112, '010-007A', 'Calculator - Desktop, DM1600', '2018-08-01 10:47:09'),
(113, '010-007B', 'Calculator - Desktop, LCD, 12 digits, 2-way power', '2018-08-01 10:47:09'),
(114, '010-007C', 'Calculator - Scientific, 10 digits, dot matrix display, programmable w.case', '2018-08-01 10:47:09'),
(115, '010-008', 'Cartolina - Assorted Colors', '2018-08-01 10:47:09'),
(116, '010-009', 'CD Rewritable/DVD RW - With Case for acctg. Reports', '2018-08-01 10:47:09'),
(117, '010-010', 'Clear Book - PVC Binding, Element Cover', '2018-08-01 10:47:09'),
(118, '010-011', 'Columnar Notebook - 5 Columns', '2018-08-01 10:47:09'),
(119, '010-012', 'Correction Tape - Disposable, 0.02x5x6', '2018-08-01 10:47:09'),
(120, '010-013', 'Cutter - for heavy duty', '2018-08-01 10:47:09'),
(121, '010-014', 'Data File Box - 5x9x15-3/4', '2018-08-01 10:47:09'),
(122, '010-015', 'Data Folder - Horizontal, with finger ring, 3x9x15', '2018-08-01 10:47:09'),
(123, '010-016A', 'EDP Binder - TB 11 x 14 7/8 CCF Plastic Spring Rod', '2018-08-01 10:47:09'),
(124, '010-016B', 'Blue Binder - w/ring, Horizontal Molar', '2018-08-01 10:47:09'),
(125, '010-016C', 'Binding Screw - 3in', '2018-08-01 10:47:09'),
(126, '010-016D', 'PVC Binding Cover - 200 mm, A4, Clear', '2018-08-01 10:47:09'),
(127, '010-016E', 'Three-Ring Binder PVC View Cover, 1.5in spine, 12 x 10 (HXW)', '2018-08-01 10:47:09'),
(128, '010-017A', 'Envelope - Documentary, Legal', '2018-08-01 10:47:09'),
(129, '010-017B', 'Envelope - Documentary, A4', '2018-08-01 10:47:09'),
(130, '010-017C', 'Envelope - Expanding, Legal', '2018-08-01 10:47:09'),
(131, '010-017D', 'Envelope - Expanding, Legal, Plastic', '2018-08-01 10:47:09'),
(132, '010-017E', 'Envelope - Pay, 400\"x7-1/12\"', '2018-08-01 10:47:09'),
(133, '010-017F', 'Envelope - White, Mailing', '2018-08-01 10:47:09'),
(134, '010-017G', 'Envelope - Expanding', '0000-00-00 00:00:00'),
(135, '010-017H', 'Envelope - Brown, A4', '2018-08-01 11:15:08'),
(136, '010-017I', 'Envelope - Brown, Legal', '2018-08-01 11:15:08'),
(137, '010-017J', 'Envelope - Documentary, 10 x 15', '2018-08-01 11:15:08'),
(138, '010-017K', 'Envelope - Legal', '2018-08-01 11:15:08'),
(139, '010-018', 'Eraser - Rubber', '2018-08-01 11:15:08'),
(140, '010-019', 'Fax Recording Paper', '2018-08-01 11:15:08'),
(141, '010-020A', 'File Folder - Brown, A4', '2018-08-01 11:15:08'),
(142, '010-020B', 'File Folder - Brown, Legal', '2018-08-01 11:15:08'),
(143, '010-020C', 'File Folder - Clear Plastic, A4 50s/pack', '2018-08-01 11:15:08'),
(144, '010-020D', 'File Folder - Clear Plastic, Legal', '2018-08-01 11:15:08'),
(145, '010-020E', 'File Folder - Clear Plastic, L-type, Legal', '2018-08-01 11:15:08'),
(146, '010-020F', 'File Folder - Horizontal', '2018-08-01 11:15:08'),
(147, '010-020G', 'File Folder - Tag board, A4', '2018-08-01 11:15:08'),
(148, '010-020H', 'File Folder - Tag board, Legal', '2018-08-01 11:15:08'),
(149, '010-020I', 'File Folder - Short', '2018-08-01 11:15:08'),
(150, '010-020J', 'File Folder - Clear Plastic, L-type, A4', '2018-08-01 11:15:08'),
(151, '010-020K', 'File Folder - Legal Size', '2018-08-01 11:15:08'),
(152, '010-020L', 'File Folder - A4 Size', '2018-08-01 11:15:08'),
(153, '010-020M', 'File Folder - A4', '2018-08-01 11:15:08'),
(154, '010-020N', 'File Folder - Legal', '2018-08-01 11:15:08'),
(155, '010-021A', 'File organizer - Legal, Expanding', '2018-08-01 11:15:08'),
(156, '010-021B', 'File Tab Divider - A4, 5 colors/set', '2018-08-01 11:15:08'),
(157, '010-022', 'Floppy Disk', '2018-08-01 11:15:08'),
(158, '010-023', 'Glue', '2018-08-01 11:15:08'),
(159, '010-024A', 'Index Card - 5 x 8, 500\'s', '2018-08-01 11:15:08'),
(160, '010-024B', 'Index Card Box', '2018-08-01 11:15:08'),
(161, '010-025A', 'Ink Cartridge - #40, Black', '2018-08-01 11:15:08'),
(162, '010-025B', 'Ink Cartridge - #41, Colored', '2018-08-01 11:15:08'),
(163, '010-025C', 'Ink Cartridge - #810, Black', '2018-08-01 11:15:08'),
(164, '010-025D', 'Ink Cartridge - #811, Colored', '2018-08-01 11:15:08'),
(165, '010-025E', 'Ink Cartridge - IP 4500', '2018-08-01 11:15:08'),
(166, '010-025F', 'Ink Cartridge - #21, C9357A, Black', '2018-08-01 11:15:08'),
(167, '010-025G', 'Ink Cartridge - #22, C9352A, Tricolor', '2018-08-01 11:15:08'),
(168, '010-025H', 'Ink Cartridge - #60, CC64BWA, Black, Standard', '2018-08-01 11:15:08'),
(169, '010-025I', 'Ink Cartridge - #60, CC64BWA, Colored, Standard', '2018-08-01 11:15:08'),
(170, '010-025J', 'Ink Cartridge - #17, Black, PN10N0217', '2018-08-01 11:15:08'),
(171, '010-025K', 'Ink Cartridge - #27, Colored, PN10N0027', '2018-08-01 11:15:08'),
(172, '010-025L', 'Ink Cartridge - Laser Jet Printer Toner Cartridge (CE310A)', '2018-08-01 11:15:08'),
(173, '010-025M', 'Ink Cartridge - L2200', '2018-08-01 11:15:08'),
(174, '010-026A', 'Magazine File Box - 110 x 220 x 265 m', '2018-08-01 11:15:08'),
(175, '010-026B', 'Magazine File Box - 112 x 200 x 240 mm', '2018-08-01 11:15:08'),
(176, '010-027', 'Magic Tape', '2018-08-01 11:15:08'),
(177, '010-028', 'Manila Paper', '2018-08-01 11:15:08'),
(178, '010-029', 'Map Pin - Round Head 100s/case', '2018-08-01 11:15:08'),
(179, '010-030A', 'Marking Pen - Fluorescent, 3 Colors/set', '2018-08-01 11:15:08'),
(180, '010-030B', 'Marking Pen - Permanent, Black, Bullet Type', '2018-08-01 11:15:08'),
(181, '010-030C', 'Marking Pen - Permanent, Blue, Bullet Type', '2018-08-01 11:15:08'),
(182, '010-030D', 'Marking Pen - Permanent, Red, Bullet Type', '2018-08-01 11:15:08'),
(183, '010-030E', 'Marking Pen - Broad', '2018-08-01 11:15:08'),
(184, '010-030F', 'Marking Pin - Permanent, Black, Chisel Type', '2018-08-01 11:15:08'),
(185, '010-031A', 'Mimeo Paper - A4', '2018-08-01 11:15:08'),
(186, '010-031B', 'Mimeo Paper - Legal', '2018-08-01 11:15:08'),
(187, '010-032A', 'Note Pad - 2 x 2, 400 sheets/pad', '2018-08-01 11:15:08'),
(188, '010-032B', 'Note Pad - 3 x 3, 100 sheets/pad', '2018-08-01 11:15:08'),
(189, '010-032C', 'Note Pad - 3 x 4, 100 sheets/pad', '2018-08-01 11:15:08'),
(190, '010-032D', 'Note Pad - 2 x 3', '2018-08-01 11:15:08'),
(191, '010-032E', 'Note Pad - 2 x 2, 400 sheets/pad', '2018-08-01 11:15:08'),
(192, '010-033', 'Notebook - Stenographers', '2018-08-01 11:15:08'),
(193, '010-034A', 'Paper Clip', '2018-08-01 11:15:08'),
(194, '010-034B', 'Paper Clip - Jumbo, Gem type, 48 mm, 100s/box', '2018-08-01 11:15:08'),
(195, '010-034C', 'Paper Clip - Small, Gem type, 33 mm., 100s/box', '2018-08-01 11:15:08'),
(196, '010-034D', 'Paper Clip - Backfold, 50mm', '2018-08-01 11:15:08'),
(197, '010-034E', 'Paper Clip - Backfold, 25mm, 12 pcs/box', '2018-08-01 11:15:08'),
(198, '010-034F', 'Paper Clip - Backfold, 32mm, 12 pcs/box', '2018-08-01 11:15:08'),
(199, '010-034G', 'Paper Clip - Backfold, 50mm, 12 pcs/box', '2018-08-01 11:15:08'),
(200, '010-034H', 'Paper Clip - Backfold, 19mm, 12 pcs/box', '2018-08-01 11:15:08'),
(201, '00101', 'Mashpotato large', '2018-08-01 15:39:36');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `purchase_id` int(11) NOT NULL,
  `po_num` varchar(255) NOT NULL,
  `po_date` date NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `unit_of_issue` varchar(255) NOT NULL,
  `fund_source` enum('General Fund','Revolving Fund') NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `purchase_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL,
  `unit_of_issue` varchar(255) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`unit_id`, `unit_of_issue`, `added_date`) VALUES
(1, 'Pc/s', '2018-08-01 11:23:11'),
(2, 'Can/s', '2018-08-01 11:23:11'),
(3, 'Bottle/s', '2018-08-01 11:23:11'),
(4, 'Gallon/s', '2018-08-01 11:23:11'),
(5, 'Pouch/es', '2018-08-01 11:23:11'),
(6, 'Kg/s', '2018-08-01 11:23:11'),
(7, 'Container/s', '2018-08-01 11:23:11'),
(8, 'Pair/s', '2018-08-01 11:23:11'),
(9, 'Liter/s', '2018-08-01 11:23:11'),
(10, 'Roll/s', '2018-08-01 11:23:11'),
(11, 'Unit/s', '2018-08-01 11:23:11'),
(12, 'Each', '2018-08-01 11:23:11'),
(13, 'Set/s', '2018-08-01 11:23:11'),
(14, 'Meter/s', '2018-08-01 11:23:11'),
(15, 'Box/es', '2018-08-01 11:23:11'),
(16, 'Pack/s', '2018-08-01 11:23:11'),
(17, 'Tube/s', '2018-08-01 11:23:11'),
(18, 'Ream/s', '2018-08-01 11:23:11'),
(19, 'Jar/s', '2018-08-01 11:23:11'),
(20, 'Cart/s', '2018-08-01 11:23:11'),
(21, 'Pad/s', '2018-08-01 11:23:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `funds`
--
ALTER TABLE `funds`
  ADD PRIMARY KEY (`fund_id`);

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `funds`
--
ALTER TABLE `funds`
  MODIFY `fund_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `issue`
--
ALTER TABLE `issue`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
