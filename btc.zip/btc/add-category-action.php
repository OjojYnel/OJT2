<center>
<?php
include 'config.php';
  session_start();

  if(isset($_POST['category']))
  {
   
    $cname = $_POST['cname'];


    $query = "INSERT INTO `categories`(`category_name`) VALUES ('$cname')";

    $result = mysqli_query($con,$query);

    if($result) {
      echo 'Category Added';
    }else{
      echo 'Category, Not Added ';
    }
    header("refresh:1;url=add.php");

    }
?>
</center>