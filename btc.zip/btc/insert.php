<center>
<?php
include 'config.php';


$pnum = $_POST['pnum'];
$pdate = $_POST['added_date'];
$pcode = $_POST['pcode'];
$product_name = $_POST['pname'];
$product_category = $_POST['pcategory'];
$product_brand = $_POST['pbrand'];
$punit = $_POST['punit'];
$fund = $_POST['fund'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];
$amt = $_POST['amt'];

$sql = "INSERT INTO purchases (po_num,po_date,product_code,product_name,category_name,brand_name,unit_of_issue,fund_source,quantity,price,purchase_amount) VALUES ('$pnum','$pdate','$pcode','$product_name','$product_category','$product_brand','$punit','$fund','$quantity','$price','$amt')";

if(!mysqli_query($con,$sql)){
	echo 'Not Inserted';
}else{
	echo 'Inserted';
}
	
header("refresh:2;url=purchase.php");

?>
</center>